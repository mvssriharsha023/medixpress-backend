package com.medixpress.order_service.response;

public enum UserType {
    CUSTOMER,
    PHARMACY
}
