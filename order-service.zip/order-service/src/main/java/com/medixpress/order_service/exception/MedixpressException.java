package com.medixpress.order_service.exception;

public class MedixpressException extends RuntimeException {
    public MedixpressException(String message) {
        super(message);
    }
}
