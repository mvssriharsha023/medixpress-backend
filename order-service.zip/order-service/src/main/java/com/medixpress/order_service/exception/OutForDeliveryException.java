package com.medixpress.order_service.exception;

public class OutForDeliveryException extends MedixpressException {
    public OutForDeliveryException(String message) {
        super(message);
    }
}
