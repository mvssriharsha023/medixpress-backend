package com.medixpress.order_service.model;

public enum OrderStatus {
    PLACED,
    OUT_OF_DELIVERY,
    DELIVERED,
    CANCELLED
}
